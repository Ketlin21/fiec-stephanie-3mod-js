import React, {useState} from 'react';
import {Container, Input, Button, Title} from './styles';


export default function Cadastro(props) {
  
  const [email, setEmail] = useState(null);
  const [pass, setPass] = useState(null);
  const [text, setText] = useState(null);
  const [EhCadastro, setEhCadastro] = useState(false);

  const cadastrar = async () => {
     const json =  JSON.stringify({
       nome: text,
       senha: pass,
       email: email
     })
     const data = await fetch("http://localhost:38000/usuarios/cadastro", {
       method: "POST",
       headers: {
         "content-type":"application/json"
       },
       body: json
     })
     const resposta = await data.json()
     console.log(resposta);

    }
    
    const login = async () => {

   const json =  JSON.stringify({
      senha: pass,
      email: email
   })
    const data = await fetch("http://localhost:38000/usuarios/autentica", {
     method: "POST",
    eaders: {
     "content-type":"application/json"
     },
    body: json
    })
   const resposta = await data.json()
    console.log(resposta);
    props.logar(true);

  }



  let campoNome = <Input type="text" name="name" placeholder="Informe seu nome"
  value={text} onChange={e=> setText(e.target.value)}
  />

  return (
   <Container> 
     <Title>Faça Seu {EhCadastro ? "Cadastro" : "Login"}</Title>
     {EhCadastro ? campoNome : ""}

      <Input type="email" placeholder="Informe seu email"
      value={email} onChange={e=> setEmail(e.target.value)}
      />
      <Input type="password" placeholder="Informe sua senha"
      value={pass} onChange={e=> setPass(e.target.value)}
      />
      <Button type = "submit" onClick={EhCadastro ? cadastrar : login}> Entrar </Button>
      <Button primary onClick={e=>setEhCadastro(!EhCadastro)}>{EhCadastro ? ("Cadastrar-se") : ("Logar-se")}</Button>
   </Container>   
  );
  }
  



  