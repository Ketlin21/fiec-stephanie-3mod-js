import React from 'react';
import ReactDOM from 'react-dom';
import Cadastro from "./Cadastro"
import 'bootstrap/dist/css/bootstrap.min.css';
import {  } from "./home";
import {HashRouter, Switch, Route} from 'react-router-dom';
import App from './App';



ReactDOM.render(
  <HashRouter>
  <React.StrictMode>
    < App/>
  </React.StrictMode>
  </HashRouter>
,
  
  document.getElementById('root')
);

