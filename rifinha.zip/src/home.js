import React from 'react'


const Home=()=> {
    return (
        <div>
   a
        </div>
    )
}



export default Home

       
