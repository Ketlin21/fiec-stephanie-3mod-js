import React from 'react';
import ReactDOM from 'react-dom';
import Cadastro from './src/Cadastro'

ReactDOM.render(<Cadastro/>,
    document.getElementById('root')
);